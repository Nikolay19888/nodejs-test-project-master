Test project description:
* MEAN stack
* Token based user authentication 
* Create Reports Add/Edit/Delete



Running the app

* npm start


Installation

* Install the application: npm install
* View in browser at http://localhost:3000
